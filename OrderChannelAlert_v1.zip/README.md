# OrderChannelAlert (RoR addon)

Author: Killamanjaro

OrderChannelAlert is a Return of Reckoning (WAR) UI addon that shows up to four simultaneous class-and-ability alerts and optionally plays a sound when configured combat abilities hit your character.

This folder is named `OrderChannelAlert` on disk and the addon/module name is `OrderChannelAlert` (see `OrderChannelAlert.mod`).

## Quick start (in game)

1. Reload the UI to ensure the addon is loaded: `/reloadui`
2. Open the config window: `/orderchannelalert`
3. Ensure the addon is enabled:
  - In the config window, toggle the **Enabled:** checkbox on (or run `/orderchannelalert on`).
4. Add an ability:
  - Enter an **Ability ID** (the numeric ability ID that appears in combat events).
  - Enter a **Name** (just for display in the list).
  - Click **+ Add**.
5. Test the alert:
  - `/orderchannelalert test` (cycles through every configured channel ability), or
  - `/orderchannelalert test <abilityId>`
6. Tune behavior in the list:
  - **On** toggles showing the icon
  - **Alert (s)** changes how long the alert stays visible; this is independent of actual ability channel duration
  - **Sound** toggles sound (sound effect is always ID **500**)
  - **Image** chooses the icon texture
  - Assign the same class image to multiple ability rows to track several abilities for one class.
  - Click **Track Classes** to enable or disable classes in the 4×3 class grid.
7. If you edit XML/Lua files, use `/reloadui` to apply changes.

## File structure

```
OrderChannelAlert/
  OrderChannelAlert.mod              # Addon manifest/entrypoint
  LICENSE.md
  README.md

  Source/
    OrderChannelAlert.xml            # Main alert window
    OrderChannelAlert.lua            # Runtime logic: events, triggers, rendering, slash commands

    OrderChannelAlert_Config.xml     # Config window + class gallery + ability row + import/export templates
    OrderChannelAlert_Config.lua     # Config behaviors: list management, handlers, import/export

  Textures/
    Alert.tga and <Career>.tga  # Retained legacy art; alerts use built-in class icons
```

## How it works (high-level code flow)

### 1) Addon initialization

Initialization is declared in `OrderChannelAlert.mod`:

- Loads XML first (creates templates/windows).
- Loads Lua (runtime + config code).
- Calls `OrderChannelAlert_OnInitialize()` and `OrderChannelAlert_Config_OnInitialize()`.
- Declares a SavedVariable: `OrderChannelAlert_Settings`.

At runtime:

- `OrderChannelAlert_OnInitialize()` (in `Source/OrderChannelAlert.lua`):
  - Seeds defaults for `OrderChannelAlert_Settings` when missing.
  - Registers `/orderchannelalert` via `LibSlash.RegisterSlashCmd`.
  - Creates the main alert window and registers it with the Layout Editor.
  - Enables the addon’s event handlers by default.

### 2) Listening for combat events

OrderChannelAlert listens to:

- `SystemData.Events.WORLD_OBJ_COMBAT_EVENT`

Handler:

- `OrderChannelAlert_OnWorldObjCombatEvent(world_object_id, ability_value, ability_type, ability_id)`
  - Ignores events not targeting the local player (`world_object_id ~= GameData.Player.worldObjNum`).
  - Looks up `OrderChannelAlert_Settings.abilities[ability_id]`.
  - Requires both the ability and its assigned class to be enabled before calling `OrderChannelAlert_Trigger(ability_id)`.

### 3) Triggering and display

`OrderChannelAlert_Trigger(ability_id)`:

- Tracks active alerts in:
  - `active_alerts[ability_id] = { started_at, expires_at, duration }`
  - `active_order` (most-recent-first ordering)
- Shows up to 4 alert cards (see `MAX_SIMULTANEOUS_ICONS = 4`):
  - Newly triggered abilities are inserted at the front of `active_order`.
  - If more than 4 are active, the oldest is evicted.
- Marks `ui_dirty = true` so the next update will render.
- Sound:
  - The sound ID is hard-coded to **500** (`MAIN_SOUND_ID = 500`).
  - Per-ability sound is controlled by `sound_enabled`.

Rendering:

- `OrderChannelAlert_OnUpdate(time_delta)`:
  - Advances a local timer (`now_seconds`).
  - Removes expired alerts.
  - Calls `OrderChannelAlert_RenderIcons()` when dirty.

- `OrderChannelAlert_RenderIcons()`:
  - Shows the game's ability icon, class icon and class abbreviation, prominent ability name, and a solid yellow **Channel!** bar.
  - Uses CCTV's background and border artwork and its small/medium Clear font styles.
  - Pulses CCTV's red background glow while each alert row is active.
  - Applies `OrderChannelAlert_Settings.window_alpha` (clamped).

The bar is a static active-state indicator; it does not display or count down an ability's duration. The configured alert timeout still controls when a row is removed, and each matching hit refreshes that timeout.

### 4) Layout editor integration

The window is registered with `LayoutEditor.RegisterWindow`.

When the layout editor begins editing:

- `OrderChannelAlert_LayoutEditor_Callback(LayoutEditor.EDITING_BEGIN)` shows a stable four-row preview so the user can position and resize the window.

When editing ends:

- The window alpha is stored back into `OrderChannelAlert_Settings.window_alpha`.

## Settings and data model

All persistent data is stored in `OrderChannelAlert_Settings` (SavedVariables). The addon migrates older formats on startup.

### Class icon display

- Alerts load class and ability icons from the game's icon data rather than displaying icon-number text.
- Existing image settings remain supported; choose a class in the **Image** dropdown to associate an ability with that class.
- Multiple ability IDs can share one class image. Each ability shows its own configured name on its alert card.
- The gallery and alert cards use the configured game icon IDs: Archmage `20180`, Bright Wizard `20183`, Ironbreaker `20187`, Engineer `20188`, Slayer `20189`, Knight of the Blazing Sun `20190`, Runepriest `20193`, Shadow Warrior `20194`, Swordmaster `20198`, Warrior Priest `20199`, White Lion `20200`, and Witch Hunter `20202`.
- Class headers use the class abbreviations in the class table (for example, **SL** for Slayer).
- Each class can be enabled or disabled in the **Track Classes** 4×3 grid, and each ability has its own toggle.
- The alert canvas starts at 520×350. Its four stacked rows reflow when resized in the Layout Editor.

Default tracked abilities are the Order channeled abilities.

## Configuration UI

### Window and layout

The configuration UI is defined in `Source/OrderChannelAlert_Config.xml` and controlled by `Source/OrderChannelAlert_Config.lua`.

It provides:

- Add new ability (ID + Name)
- Enabled toggle
- Duration edit
- Sound toggle
- Image/texture picker
- Delete ability
- Import / Export popup dialog
- Class tracking toggles in a 4×3 icon grid
- Per-ability tracking toggles and configurable alert timeout

Note: Some WAR UI templates do not reliably render XML `text="..."` attributes for certain controls, so key label/button text is also set explicitly in Lua during `OrderChannelAlert_Config_OnInitialize()`.

### Enabling/disabling the addon

The “Enabled” checkbox in the config window toggles whether the runtime registers for combat events:

- `OrderChannelAlert_Config_OnToggleAddonEnabled()` calls `OrderChannelAlert_SetEnabled(true|false)`.

## Import / Export

Import/Export uses a compact single-line string format (copy/paste).

- Export replaces line breaks with a single-line payload.
- Import **replaces your entire ability list** (`OrderChannelAlert_Settings.abilities`).

### Format

Prefix:

- `AAE1|`

Entries:

- Separated by `;`

Each entry:

```
abilityId,enabled(0/1),sound(0/1),duration,texLen:texture,nameLen:name
```

Texture and name are length-prefixed so they don’t need escaping.

Limits:

- Maximum import size: 1 MiB
- Maximum number of abilities per import: 500

## Slash commands

Registered as `/orderchannelalert`.

- `/orderchannelalert`
  - Opens the config window.

- `/orderchannelalert help`
  - Prints available commands.

- `/orderchannelalert on` / `/orderchannelalert off`
  - Enables/disables event listening + alert rendering.

- `/orderchannelalert duration <seconds>`
  - Sets the duration for **all** configured abilities.

- `/orderchannelalert layer <background|default|overlay|popup|secondary>`
  - Changes the UI layer for the alert window.

- `/orderchannelalert sound on|off`
  - Enables/disables sound for **all** configured abilities.
  - Sound effect is the built-in game sound ID **500**. The WAR addon `PlaySound` API accepts game sound IDs, not WAV file paths, so `output.wav` cannot be played directly by this addon.

- `/orderchannelalert test [abilityId]`
  - Without an ID, each invocation advances to the next configured channel ability in ability-ID order, wrapping to the start after the last one. Testing ignores tracking and enabled filters so every configured row can be previewed.
  - With an ID, previews that configured ability specifically.

- `/orderchannelalert debug on|off`
  - Toggles debug chat output.

## Notes for maintainers

- This addon intentionally avoids filesystem enumeration (WAR UI doesn’t provide a general API for it). The texture list is seeded with known textures and any additional texture names found in saved settings.
- Runtime and config are decoupled: the config window edits `OrderChannelAlert_Settings` directly, and the runtime reads from it when combat events arrive.

## Troubleshooting

- If the config window fails to open, check the chat log for:
  - `OrderChannelAlert: config window failed to load (check OrderChannelAlert_Config.xml).`
- After changing XML/Lua, use `/reloadui`.
