<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="OrderChannelAlert" version="1.0" date="18/02/2026">

    <Author name="Killamanjaro" />

    <Dependencies>
      <Dependency name="EASystem_LayoutEditor" />
      <Dependency name="LibSlash" optional="false" />
    </Dependencies>

    <Description text="Shows up to four configurable channel alerts with ability and class icons when tracked Order abilities hit you. Use /orderchannelalert to configure." />

    <Files>
      <File name="Source\OrderChannelAlert.xml" />
      <File name="Source\OrderChannelAlert_Config.xml" />
      <File name="Source\OrderChannelAlert.lua" />
      <File name="Source\OrderChannelAlert_Config.lua" />
    </Files>

    <OnInitialize>
      <CallFunction name="OrderChannelAlert_OnInitialize" />
      <CallFunction name="OrderChannelAlert_Config_OnInitialize" />
    </OnInitialize>

    <OnShutdown>
      <CallFunction name="OrderChannelAlert_OnShutdown" />
    </OnShutdown>

    <SavedVariables>
      <SavedVariable name="OrderChannelAlert_Settings" />
    </SavedVariables>   

    <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

    <WARInfo>
      <Categories>
        <Category name="COMBAT" />
      </Categories>
    </WARInfo>

  </UiMod>
</ModuleFile>
