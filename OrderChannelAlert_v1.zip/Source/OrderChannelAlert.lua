local WINDOW_NAME = "OrderChannelAlert_Main"
local orderchannelalert_is_enabled = false

local MAIN_SOUND_ID = 999
local SOUND_REPEAT_COUNT = 3
local SOUND_REPEAT_INTERVAL = 2.5
local sounds_remaining = 0
local next_sound_at = 0

local MAX_SIMULTANEOUS_ICONS = 4

-- Active alerts keyed by ability_id.
-- Each entry: { started_at = number, expires_at = number, duration = number }
local active_alerts = {}
local active_order = {}
local now_seconds = 0
local ui_dirty = true
local layout_editor_active = false
local missing_icon_warnings = {}
local missing_ability_warnings = {}
local test_ability_cursor = 0
local OrderChannelAlert_IconWindowName

OrderChannelAlert_ClassKeys = {
  "Archmage", "BrightWizard", "Ironbreaker", "Engineer",
  "Slayer", "KnightOfTheBlazingSun", "Runepriest", "ShadowWarrior",
  "SwordMaster", "WarriorPriest", "WhiteLion", "WitchHunter",
}

OrderChannelAlert_ClassNames = {
  Engineer = "Engineer",
  Ironbreaker = "Ironbreaker",
  Runepriest = "Runepriest",
  Slayer = "Slayer",
  BrightWizard = "Bright Wizard",
  KnightOfTheBlazingSun = "Knight of the Blazing Sun",
  WarriorPriest = "Warrior Priest",
  WitchHunter = "Witch Hunter",
  Archmage = "Archmage",
  ShadowWarrior = "Shadow Warrior",
  SwordMaster = "Sword Master",
  WhiteLion = "White Lion",
}

OrderChannelAlert_ClassAbbreviations = {
  Archmage = "AM",
  BrightWizard = "BW",
  Ironbreaker = "Ing",
  Engineer = "IB",
  Slayer = "SL",
  KnightOfTheBlazingSun = "KotBS",
  Runepriest = "RP",
  ShadowWarrior = "SW",
  SwordMaster = "SM",
  WarriorPriest = "WP",
  WhiteLion = "WL",
  WitchHunter = "WH",
}

OrderChannelAlert_ClassIconIds = {
  Archmage = 20180,
  BrightWizard = 20183,
  Ironbreaker = 20188,
  Engineer = 20187,
  Slayer = 20189,
  KnightOfTheBlazingSun = 20190,
  Runepriest = 20193,
  ShadowWarrior = 20194,
  SwordMaster = 20198,
  WarriorPriest = 20199,
  WhiteLion = 20200,
  WitchHunter = 20202,
}

-- Ability ID -> texture registered in OrderChannelAlert.xml (files in Textures\Abilities\<id>.tga).
OrderChannelAlert_LocalAbilityTextures = {
  [8244] = "OrderChannelAlert_Ability8244",
  [1457] = "OrderChannelAlert_Ability1457",
  [1450] = "OrderChannelAlert_Ability1450",
  [8031] = "OrderChannelAlert_Ability8031",
  [8087] = "OrderChannelAlert_Ability8087",
  [1528] = "OrderChannelAlert_Ability1528",
  [1385] = "OrderChannelAlert_Ability1385",
  [9026] = "OrderChannelAlert_Ability9026",
  [9021] = "OrderChannelAlert_Ability9021",
  [1614] = "OrderChannelAlert_Ability1614",
  [9250] = "OrderChannelAlert_Ability9250",
  [9164] = "OrderChannelAlert_Ability9164",
  [9188] = "OrderChannelAlert_Ability9188",
  [9106] = "OrderChannelAlert_Ability9106",
  [9101] = "OrderChannelAlert_Ability9101",
  [8183] = "OrderChannelAlert_Ability8183",
  [8185] = "OrderChannelAlert_Ability8185",
  [8187] = "OrderChannelAlert_Ability8187",
  [8177] = "OrderChannelAlert_Ability8177",
}

local last_layout_w = nil

local function OrderChannelAlert_ClassInfoForTexture(texture)
  if type(texture) ~= "string" then
    return nil, nil, L"Unknown"
  end
  local key = texture:gsub("^OrderChannelAlert_", "")
  local icon_id = OrderChannelAlert_ClassIconIds[key]
  local class_name = OrderChannelAlert_ClassNames[key]
  if not icon_id or not class_name then
    return nil, nil, L"Unknown"
  end
  local abbreviation = OrderChannelAlert_ClassAbbreviations[key]
  -- Roughly 7px per character in font_clear_small; the label starts after the class icon.
  local available = (last_layout_w or 520) - 82 - 30 - 10
  if #class_name * 7 > available then
    return key, icon_id, towstring(abbreviation or class_name)
  end
  return key, icon_id, towstring(class_name)
end

local function OrderChannelAlert_ClampAlpha(a)
  if type(a) ~= "number" then
    return 1.0
  end
  if a < 0.05 then
    return 0.05
  end
  if a > 1.0 then
    return 1.0
  end
  return a
end

local function OrderChannelAlert_ResolveTexture(texture)
  if type(texture) ~= "string" or texture == "" then
    return "OrderChannelAlert_Alert"
  end

  if texture == "Alert" or texture == "OrderChannelAlert_Alert" then
    return "OrderChannelAlert_Alert"
  end

  for _, class_key in ipairs(OrderChannelAlert_ClassKeys) do
    if texture == class_key or texture == "OrderChannelAlert_" .. class_key then
      return "OrderChannelAlert_" .. class_key
    end
  end

  local normalized = texture:gsub("/", "\\")
  local file_name = string.match(normalized, "^Textures\\(.+)%.tga$")
  if file_name then
    if file_name == "Alert" then
      return "OrderChannelAlert_Alert"
    end
    for _, class_key in ipairs(OrderChannelAlert_ClassKeys) do
      if file_name == class_key then
        return "OrderChannelAlert_" .. class_key
      end
    end
  end
  return texture
end

local function OrderChannelAlert_EnsureWindow()
  if not DoesWindowExist(WINDOW_NAME) then
    CreateWindow(WINDOW_NAME, true)
    WindowSetAlpha(WINDOW_NAME, 0.0)
    WindowSetLayer(WINDOW_NAME, OrderChannelAlert_Settings.window_layer)
  end

  for i = 1, MAX_SIMULTANEOUS_ICONS do
    local row_name = OrderChannelAlert_IconWindowName(i)
    if not DoesWindowExist(row_name) then
      CreateWindowFromTemplate(row_name, "OrderChannelAlert_AlertRowTemplate", WINDOW_NAME)
      WindowSetShowing(row_name, false)
      local bar_name = row_name .. "ChannelBar"
      if DoesWindowExist(bar_name) then
        StatusBarSetForegroundTint(bar_name, 255, 204, 0)
        StatusBarSetBackgroundTint(bar_name, 10, 10, 10)
      end
    end
  end
end

OrderChannelAlert_IconWindowName = function(index)
  return WINDOW_NAME .. "Icon" .. tostring(index)
end

local function OrderChannelAlert_ClassIconWindowName(index)
  return WINDOW_NAME .. "Icon" .. tostring(index) .. "ClassIcon"
end

local function OrderChannelAlert_ClassNameWindowName(index)
  return WINDOW_NAME .. "Icon" .. tostring(index) .. "ClassName"
end

local function OrderChannelAlert_AbilityIconWindowName(index)
  return WINDOW_NAME ..   "Icon" .. tostring(index) .. "AbilityIconFrameIcon"
end

local function OrderChannelAlert_AbilityIconFrameWindowName(index)
  return WINDOW_NAME .. "Icon" .. tostring(index) .. "AbilityIconFrame"
end

local function OrderChannelAlert_NameWindowName(index)
  return WINDOW_NAME .. "Icon" .. tostring(index) .. "Name"
end

local function OrderChannelAlert_SetImage(window_name, icon_id, alpha, warning_key, target_size)
  if not DoesWindowExist(window_name) then
    local key = "window:" .. window_name
    if not missing_icon_warnings[key] then
      missing_icon_warnings[key] = true
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: icon window not found: " .. towstring(window_name))
    end
    return
  end
  icon_id = tonumber(icon_id)
  if not icon_id then
    WindowSetShowing(window_name, false)
    WindowSetAlpha(window_name, 0.0)
    return
  end
  if type(GetIconData) ~= "function" then
    WindowSetShowing(window_name, false)
    WindowSetAlpha(window_name, 0.0)
    local key = "api:" .. tostring(warning_key or icon_id)
    if not missing_icon_warnings[key] then
      missing_icon_warnings[key] = true
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: GetIconData is unavailable.")
    end
    return
  end
  local texture, tex_x, tex_y = GetIconData(icon_id)
  if texture and texture ~= "icon000000" then
    DynamicImageSetTexture(window_name, texture, tex_x, tex_y)
    -- target_size is unused for window sizing; layout code sets the window size.
    WindowSetShowing(window_name, true)
    if WindowSetTintColor then
      WindowSetTintColor(window_name, 255, 255, 255)
    end
    WindowSetAlpha(window_name, alpha)
    return
  end
  WindowSetShowing(window_name, false)
  WindowSetAlpha(window_name, 0.0)
  local key = warning_key or tostring(icon_id)
  if not missing_icon_warnings[key] then
    missing_icon_warnings[key] = true
    TextLogAddEntry("Chat", 0, L"OrderChannelAlert: unable to load icon " .. towstring(key))
  end
end

function OrderChannelAlert_TogglePulse()
  local row_name = SystemData.ActiveWindow and SystemData.ActiveWindow.name
  if not row_name or not DoesWindowExist(row_name .. "Background2") then
    return
  end
  local pulse_name = row_name .. "Background2"
  if WindowGetShowing(row_name) then
    WindowStartAlphaAnimation(pulse_name, Window.AnimationType.LOOP, 1.0, 0.0, 0.4, true, 0.0, 0)
  else
    WindowStopAlphaAnimation(pulse_name)
    WindowSetAlpha(pulse_name, 1.0)
  end
end

local function OrderChannelAlert_AbilityIconId(ability_id)
  if type(ability_id) ~= "number" then
    return nil
  end
  local ability
  if type(GetAbilityData) == "function" then
    ability = GetAbilityData(ability_id)
  end
  local function valid_icon(n)
    n = tonumber(n)
    if not n or n <= 0 or type(GetIconData) ~= "function" then
      return nil
    end
    local tex = GetIconData(n)
    if tex and tex ~= "icon000000" then
      return n
    end
    return nil
  end
  local ability_type = type(ability)
  if ability_type == "table" then
    local icon_id = valid_icon(ability.iconNum) or valid_icon(ability.iconId) or valid_icon(ability.icon)
    if icon_id then
      return icon_id
    end
    if not missing_ability_warnings["keys" .. ability_id] then
      missing_ability_warnings["keys" .. ability_id] = true
      local keys = {}
      for k, v in pairs(ability) do
        keys[#keys + 1] = tostring(k) .. "=" .. tostring(v)
      end
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: ability " .. towstring(ability_id) .. L" data: " .. towstring(table.concat(keys, ", ")))
    end
  end
  -- Some channel IDs carry no iconNum; treat the ID itself as an icon ID as a last resort.
  local fallback = valid_icon(ability_id)
  if fallback then
    return fallback
  end
  if not missing_ability_warnings[ability_id] then
    missing_ability_warnings[ability_id] = true
    TextLogAddEntry("Chat", 0, L"OrderChannelAlert: unable to load ability icon for " .. towstring(ability_id))
  end
  return nil
end

local function OrderChannelAlert_SetCardContent(index, config, ability_id, alpha)
  local class_key, class_icon_id, class_name = OrderChannelAlert_ClassInfoForTexture(config.texture)
  OrderChannelAlert_SetImage(OrderChannelAlert_ClassIconWindowName(index), class_icon_id, alpha, class_key, 24)
  local ability_window = OrderChannelAlert_AbilityIconWindowName(index)
  local local_texture = ability_id and OrderChannelAlert_LocalAbilityTextures[ability_id]
  if local_texture and DoesWindowExist(ability_window) then
    -- Bundled 64x64 icon from Textures\Abilities, no game icon lookup needed.
    DynamicImageSetTexture(ability_window, local_texture, 0, 0)
    DynamicImageSetTextureScale(ability_window, 44 / 64)
    WindowSetShowing(ability_window, true)
    WindowSetAlpha(ability_window, alpha)
  else
    if DoesWindowExist(ability_window) then
      DynamicImageSetTextureScale(ability_window, 0.43)
    end
    OrderChannelAlert_SetImage(ability_window, OrderChannelAlert_AbilityIconId(ability_id), alpha, ability_id)
  end

  local name_label = OrderChannelAlert_ClassNameWindowName(index)
  if DoesWindowExist(name_label) then
    LabelSetText(name_label, class_key and class_name or L"")
    WindowSetAlpha(name_label, alpha)
  end
  name_label = WINDOW_NAME .. "Icon" .. tostring(index) .. "ClassNameBG"
  if DoesWindowExist(name_label) then
    LabelSetText(name_label, class_key and class_name or L"")
    WindowSetAlpha(name_label, alpha)
  end

  name_label = OrderChannelAlert_NameWindowName(index)
  if DoesWindowExist(name_label) then
    LabelSetText(name_label, ability_id and towstring(config.name or "") or L"")
    WindowSetAlpha(name_label, alpha)
  end
  name_label = WINDOW_NAME .. "Icon" .. tostring(index) .. "NameBG"
  if DoesWindowExist(name_label) then
    LabelSetText(name_label, ability_id and towstring(config.name or "") or L"")
    WindowSetAlpha(name_label, alpha)
  end
end

local function OrderChannelAlert_SetChannelBar(index, alpha)
  local bar = WINDOW_NAME .. "Icon" .. tostring(index) .. "ChannelBar"
  local text = WINDOW_NAME .. "Icon" .. tostring(index) .. "ChannelText"
  if DoesWindowExist(bar) then
    StatusBarSetMaximumValue(bar, 1)
    StatusBarSetCurrentValue(bar, 1)
    WindowSetAlpha(bar, alpha)
  end
  if DoesWindowExist(text) then
    LabelSetText(text, L"Channel!")
    WindowSetAlpha(text, alpha)
  end
end

local last_layout_h = nil

local function OrderChannelAlert_LayoutIconsIfNeeded()
  if not (WindowGetDimensions and WindowSetDimensions and WindowClearAnchors and WindowAddAnchor) then
    return
  end

  if not DoesWindowExist(WINDOW_NAME) then
    return
  end

  local w, h = WindowGetDimensions(WINDOW_NAME)
  if type(w) ~= "number" or type(h) ~= "number" then
    return
  end

  if w < 2 or h < 2 then
    return
  end

  local minimum_width = 320
  local minimum_height = MAX_SIMULTANEOUS_ICONS * 92 + 4 * (MAX_SIMULTANEOUS_ICONS - 1)
  local adjusted_w = math.max(w, minimum_width)
  local adjusted_h = math.max(h, minimum_height)
  if adjusted_w ~= w or adjusted_h ~= h then
    WindowSetDimensions(WINDOW_NAME, adjusted_w, adjusted_h)
    w = adjusted_w
    h = adjusted_h
  end

  if w == last_layout_w and h == last_layout_h then
    return
  end

  last_layout_w = w
  last_layout_h = h

  local gap = 4
  local icon_w = math.max(1, w)
  local icon_h = math.max(1, math.floor((h - gap * (MAX_SIMULTANEOUS_ICONS - 1)) / MAX_SIMULTANEOUS_ICONS))
  local padding = math.max(4, math.min(12, math.floor(math.min(icon_w, icon_h) * 0.035)))
  local icon_size = 60
  local text_x = padding + icon_size + padding
  local channel_label_width = math.min(58, math.max(32, math.floor(icon_w * 0.25)))
  local text_width = math.max(1, icon_w - text_x - padding)
  local class_h = math.max(16, math.floor(icon_h * 0.24))
  local bar_h = 13
  local title_h = math.max(24, math.floor(icon_h * 0.36))
  local class_icon_size = math.max(16, math.min(class_h, 26))

  for i = 1, MAX_SIMULTANEOUS_ICONS do
    local icon_window = OrderChannelAlert_IconWindowName(i)
    if DoesWindowExist(icon_window) then
      WindowSetDimensions(icon_window, icon_w, icon_h)
      WindowClearAnchors(icon_window)

      local y = (i - 1) * (icon_h + gap)
      WindowAddAnchor(icon_window, "topleft", WINDOW_NAME, "topleft", 0, y)

      local class_icon_label = OrderChannelAlert_ClassIconWindowName(i)
      if DoesWindowExist(class_icon_label) then
        WindowSetDimensions(class_icon_label, class_icon_size, class_icon_size)
        WindowClearAnchors(class_icon_label)
        WindowAddAnchor(class_icon_label, "topleft", icon_window, "topleft", text_x, padding + title_h)
      end

      local ability_icon_frame = OrderChannelAlert_AbilityIconFrameWindowName(i)
      if DoesWindowExist(ability_icon_frame) then
        WindowSetDimensions(ability_icon_frame, 60, 60)
        WindowClearAnchors(ability_icon_frame)
        WindowAddAnchor(ability_icon_frame, "left", icon_window, "left", 8, 0)
      end

      for _, class_label in ipairs({ OrderChannelAlert_ClassNameWindowName(i), icon_window .. "ClassNameBG" }) do
        if DoesWindowExist(class_label) then
          WindowSetDimensions(class_label, math.max(1, text_width - class_icon_size - 4), class_h)
          WindowClearAnchors(class_label)
          local shadow_offset = string.match(class_label, "ClassNameBG$") and 2 or 0
          WindowAddAnchor(class_label, "topleft", icon_window, "topleft", text_x + class_icon_size + 4 + shadow_offset, padding + title_h + shadow_offset)
        end
      end

      for _, ability_label in ipairs({ OrderChannelAlert_NameWindowName(i), icon_window .. "NameBG" }) do
        if DoesWindowExist(ability_label) then
          WindowSetDimensions(ability_label, text_width, title_h)
          WindowClearAnchors(ability_label)
          local shadow_offset = string.match(ability_label, "NameBG$") and 2 or 0
          WindowAddAnchor(ability_label, "topleft", icon_window, "topleft", text_x + shadow_offset + 4, padding + shadow_offset + 4)
        end
      end

      local timer_bar_name = WINDOW_NAME .. "Icon" .. tostring(i) .. "ChannelTimerBar"
      if DoesWindowExist(timer_bar_name) then
        WindowSetDimensions(timer_bar_name, 172, bar_h)
        WindowClearAnchors(timer_bar_name)
        WindowAddAnchor(timer_bar_name, "bottomleft", icon_window, "bottomleft",         text_x + 7, -14)
      end
      local channel_name = WINDOW_NAME .. "Icon" .. tostring(i) .. "ChannelText"
      if DoesWindowExist(channel_name) then
        WindowSetDimensions(channel_name, 172, bar_h)
        WindowClearAnchors(channel_name)
        WindowAddAnchor(channel_name, "bottomleft", icon_window, "bottomleft", text_x + 7, -14)
      end
    end
  end
end


local function OrderChannelAlert_HideAllIcons()
  for i = 1, MAX_SIMULTANEOUS_ICONS do
    local icon_window = OrderChannelAlert_IconWindowName(i)
    if DoesWindowExist(icon_window) then
      WindowSetShowing(icon_window, false)
      WindowSetAlpha(icon_window, 1.0)
    end
    OrderChannelAlert_SetImage(OrderChannelAlert_ClassIconWindowName(i), nil, 0.0)
    OrderChannelAlert_SetImage(OrderChannelAlert_AbilityIconWindowName(i), nil, 0.0)
    OrderChannelAlert_SetCardContent(i, { texture = "", name = "" }, nil, 0.0)
    OrderChannelAlert_SetChannelBar(i, 0.0)
  end
end

local function OrderChannelAlert_RenderIcons()
  OrderChannelAlert_EnsureWindow()

  if layout_editor_active then
    return
  end

  OrderChannelAlert_LayoutIconsIfNeeded()

  local visible_count = #active_order
  if visible_count > MAX_SIMULTANEOUS_ICONS then
    visible_count = MAX_SIMULTANEOUS_ICONS
  end

  if visible_count <= 0 then
    OrderChannelAlert_HideAllIcons()
    WindowSetAlpha(WINDOW_NAME, 0.0)
    return
  end

  local alpha = OrderChannelAlert_ClampAlpha(OrderChannelAlert_Settings.window_alpha)
  -- Parent is only a movable container; keep it fully opaque to avoid any
  -- engine-specific parent/child alpha multiplication.
  WindowSetAlpha(WINDOW_NAME, 1.0)

  for i = 1, MAX_SIMULTANEOUS_ICONS do
    local icon_window = OrderChannelAlert_IconWindowName(i)
    if i <= visible_count then
      local ability_id = active_order[i]
      local cfg = OrderChannelAlert_Settings.abilities and OrderChannelAlert_Settings.abilities[ability_id]
      local entry = active_alerts[ability_id]
      if cfg then
        WindowSetShowing(icon_window, true)
        WindowSetAlpha(icon_window, 1.0)
        OrderChannelAlert_SetCardContent(i, cfg, ability_id, alpha)
        OrderChannelAlert_SetChannelBar(i, alpha)
      else
        WindowSetShowing(icon_window, false)
        WindowSetAlpha(icon_window, 1.0)
        OrderChannelAlert_SetCardContent(i, { texture = "", name = "" }, nil, 0.0)
        OrderChannelAlert_SetChannelBar(i, 0.0)
      end
    else
      WindowSetShowing(icon_window, false)
      WindowSetAlpha(icon_window, 1.0)
      OrderChannelAlert_SetCardContent(i, { texture = "", name = "" }, nil, 0.0)
      OrderChannelAlert_SetChannelBar(i, 0.0)
    end
  end
end

-- ADDON SETTINGS (SAVED BY THE CLIENT)

-- IMPORTANT: SavedVariables are loaded by the client before addon init.
-- Do NOT overwrite them here, only seed defaults when missing.
if type(OrderChannelAlert_Settings) ~= "table" then
  OrderChannelAlert_Settings = {
    version = 1.0,
    window_alpha = 1.0,
    window_layer = Window.Layers.POPUP,
    debug = false,
    abilities = {
      [1528] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Engineer", name = "Focused Fire" },
      [1385] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Ironbreaker", name = "Grudge-Born Fury" },
      [1614] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Runepriest", name = "Rune of Burning" },
      [1457] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Slayer", name = "Rune of Absorption" },
      [1450] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Slayer", name = "Retribution" },
      [8183] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "BrightWizard", name = "Fireball Barrage" },
      [8185] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "BrightWizard", name = "Withering Heat" },
      [8187] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "BrightWizard", name = "Annihilate" },
      [8177] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "BrightWizard", name = "Rain of Fire" },
      [8031] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "KnightOfTheBlazingSun", name = "Myrmidia's Fury" },
      [8244] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "WarriorPriest", name = "Divine Assault" },
      [8087] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "WitchHunter", name = "Trial By Pain" },
      [9250] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Archmage", name = "Searing Touch" },
      [9101] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "ShadowWarrior", name = "Rapid Fire" },
      [9106] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "ShadowWarrior", name = "Swift Strikes" },
      [9026] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "SwordMaster", name = "Ether Dance" },
      [9021] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "SwordMaster", name = "Wall of Darting Steel" },
      [9164] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "WhiteLion", name = "Nature's Bond" },
      [9188] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "WhiteLion", name = "Whirling Axe" }
    }
  }
end

if type(OrderChannelAlert_Settings.tracked_classes) ~= "table" then
  OrderChannelAlert_Settings.tracked_classes = {}
end
for _, class_key in ipairs(OrderChannelAlert_ClassKeys) do
  if OrderChannelAlert_Settings.tracked_classes[class_key] == nil then
    OrderChannelAlert_Settings.tracked_classes[class_key] = true
  end
end
if type(OrderChannelAlert_Settings.abilities) ~= "table" then
  OrderChannelAlert_Settings.abilities = {}
end

local function OrderChannelAlert_IsClassTracked(texture)
  local class_key = OrderChannelAlert_ClassInfoForTexture(texture)
  if class_key == nil then
    return true
  end
  if type(OrderChannelAlert_Settings.tracked_classes) ~= "table" then
    OrderChannelAlert_Settings.tracked_classes = {}
  end
  if OrderChannelAlert_Settings.tracked_classes[class_key] == nil then
    OrderChannelAlert_Settings.tracked_classes[class_key] = true
  end
  return OrderChannelAlert_Settings.tracked_classes[class_key] == true
end

function OrderChannelAlert_Debug(message)
  if not OrderChannelAlert_Settings or not OrderChannelAlert_Settings.debug then
    return
  end
  if type(message) == "string" then
    message = towstring(message)
  end
  TextLogAddEntry("Chat", 0, message)
end

--------------------------------------------------------------------------------
-- CORE FUNCTIONS
--------------------------------------------------------------------------------

local function OrderChannelAlert_Disable ()

  if not orderchannelalert_is_enabled then
    return
  end

  active_alerts = {}
  active_order = {}
  now_seconds = 0
  ui_dirty = true
  WindowSetAlpha (WINDOW_NAME, 0.0)
  OrderChannelAlert_HideAllIcons()

  UnregisterEventHandler (SystemData.Events.UPDATE_PROCESSED, "OrderChannelAlert_OnUpdate")
  UnregisterEventHandler (SystemData.Events.WORLD_OBJ_COMBAT_EVENT, "OrderChannelAlert_OnWorldObjCombatEvent")

  orderchannelalert_is_enabled = false

end

local function OrderChannelAlert_Enable ()

  if orderchannelalert_is_enabled then
    return
  end

  active_alerts = {}
  active_order = {}
  now_seconds = 0
  ui_dirty = true
  WindowSetAlpha (WINDOW_NAME, 0.0)
  OrderChannelAlert_HideAllIcons()

  RegisterEventHandler (SystemData.Events.UPDATE_PROCESSED, "OrderChannelAlert_OnUpdate")
  RegisterEventHandler (SystemData.Events.WORLD_OBJ_COMBAT_EVENT, "OrderChannelAlert_OnWorldObjCombatEvent")

  orderchannelalert_is_enabled = true

end

-- Exposed for UI/config.
function OrderChannelAlert_NormalizeTexture(texture)
  return OrderChannelAlert_ResolveTexture(texture)
end

function OrderChannelAlert_IsEnabled()
  return orderchannelalert_is_enabled == true
end

function OrderChannelAlert_SetEnabled(enabled)
  if enabled == true then
    OrderChannelAlert_Enable()
  else
    OrderChannelAlert_Disable()
  end
end

function OrderChannelAlert_OnTrackingChanged()
  for index = #active_order, 1, -1 do
    local ability_id = active_order[index]
    local config = OrderChannelAlert_Settings.abilities[ability_id]
    if not config or config.enabled ~= true or not OrderChannelAlert_IsClassTracked(config.texture) then
      table.remove(active_order, index)
      active_alerts[ability_id] = nil
    end
  end
  ui_dirty = true
end

local function OrderChannelAlert_LayoutEditor_Callback (edit_mode)

  if (edit_mode == LayoutEditor.EDITING_BEGIN)
  then

    layout_editor_active = true

    OrderChannelAlert_EnsureWindow()
    OrderChannelAlert_LayoutIconsIfNeeded()
    -- Show a stable preview while the user is positioning/resizing the parent.
    local alpha = OrderChannelAlert_ClampAlpha(OrderChannelAlert_Settings.window_alpha)
    WindowSetAlpha(WINDOW_NAME, alpha)
    for i = 1, MAX_SIMULTANEOUS_ICONS do
      local icon_window = OrderChannelAlert_IconWindowName(i)
      WindowSetShowing(icon_window, true)
      WindowSetAlpha(icon_window, 1.0)
      local class_key = OrderChannelAlert_ClassKeys[i]
      local sample_id = nil
      for ability_id, cfg in pairs(OrderChannelAlert_Settings.abilities) do
        if OrderChannelAlert_ClassInfoForTexture(cfg.texture) == class_key then
          sample_id = ability_id
          break
        end
      end
      local cfg = sample_id and OrderChannelAlert_Settings.abilities[sample_id] or { texture = "OrderChannelAlert_" .. class_key, name = "SAMPLE CHANNEL" }
      if not sample_id then
        cfg = { texture = "OrderChannelAlert_" .. class_key, name = "SAMPLE CHANNEL" }
      end
      OrderChannelAlert_SetCardContent(i, cfg, sample_id, 1.0)
      OrderChannelAlert_SetChannelBar(i, 1.0)
    end

  elseif (edit_mode == LayoutEditor.EDITING_END)
  then

    layout_editor_active = false

    -- Save the current alpha of the parent window as the desired alpha.
    local raw_alpha = WindowGetAlpha(WINDOW_NAME)
    if type(raw_alpha) == "number" and raw_alpha > 0 then
      OrderChannelAlert_Settings.window_alpha = OrderChannelAlert_ClampAlpha(raw_alpha)
    end
    
    active_alerts = {}
    active_order = {}
    ui_dirty = true
    WindowSetAlpha (WINDOW_NAME, 0.0)
    OrderChannelAlert_HideAllIcons()

  end

end

local function OrderChannelAlert_Trigger (ability_id, force_test)

  local ability_config = OrderChannelAlert_Settings.abilities[ability_id]
  if not ability_config or (force_test ~= true and (ability_config.enabled ~= true or not OrderChannelAlert_IsClassTracked(ability_config.texture))) then
    return
  end

  OrderChannelAlert_EnsureWindow()

  local duration = tonumber(ability_config.duration) or 1.5
  if duration <= 0 then
    duration = 1.5
  end
  if force_test == true and duration < 4 then
    duration = 4
  elseif force_test ~= true and duration < 2.5 then
    -- Channel ticks can be ~2s apart; keep the alert up between ticks.
    duration = 2.5
  end

  local is_new_alert = not active_alerts[ability_id]
  if not is_new_alert then
    -- Each tick of the channel refreshes the timer without changing the slot.
    active_alerts[ability_id].started_at = now_seconds
    active_alerts[ability_id].duration = duration
    active_alerts[ability_id].expires_at = now_seconds + duration
  else
    active_alerts[ability_id] = {
      started_at = now_seconds,
      expires_at = now_seconds + duration,
      duration = duration,
    }

    table.insert(active_order, 1, ability_id)
    if #active_order > MAX_SIMULTANEOUS_ICONS then
      local evicted_id = table.remove(active_order)
      active_alerts[evicted_id] = nil
    end
  end

  ui_dirty = true

  -- If the addon is disabled (e.g. via config toggle), do not emit sound.
  -- Only a newly started channel makes noise, not every tick that refreshes it.
  if is_new_alert and (force_test == true or (orderchannelalert_is_enabled and ability_config.sound_enabled == true)) then
    sounds_remaining = SOUND_REPEAT_COUNT
    next_sound_at = now_seconds
  end

end

-- Exposed for the config UI (preview/test).
function OrderChannelAlert_TriggerAbility(ability_id)
  OrderChannelAlert_Trigger(ability_id)
end

--------------------------------------------------------------------------------
-- EVENTS
--------------------------------------------------------------------------------

function OrderChannelAlert_OnInitialize ()

  if LibSlash and type(LibSlash.RegisterSlashCmd) == "function" then
    LibSlash.RegisterSlashCmd ("orderchannelalert", OrderChannelAlert_OnSlashCmd)
  else
    TextLogAddEntry("Chat", 0, L"OrderChannelAlert: LibSlash not available; slash commands disabled.")
  end

  OrderChannelAlert_EnsureWindow()
  WindowSetAlpha (WINDOW_NAME, 0.0)
  WindowSetLayer (WINDOW_NAME, OrderChannelAlert_Settings.window_layer)

  OrderChannelAlert_HideAllIcons()

  -- Internal window name, display name, description, allow resizing X, allow resizing Y, allow hiding, on-hide call-back.
  if LayoutEditor and type(LayoutEditor.RegisterWindow) == "function" and type(LayoutEditor.RegisterEditCallback) == "function" then
    LayoutEditor.RegisterWindow (WINDOW_NAME, L"OrderChannelAlert", L"OrderChannelAlert", true, true, true, nil)
    LayoutEditor.RegisterEditCallback (OrderChannelAlert_LayoutEditor_Callback)
  else
    TextLogAddEntry("Chat", 0, L"OrderChannelAlert: LayoutEditor not available; move/resize preview disabled.")
  end

  OrderChannelAlert_Enable ()

end

function OrderChannelAlert_OnSlashCmd (text)

  -- If no parameters, open the config window
  if text == "" or text == nil then
    if OrderChannelAlert_Config_ToggleWindow then
      OrderChannelAlert_Config_ToggleWindow()
    else
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: config window is not loaded.")
    end
    return
  end

  local params = {}

  -- Build a list of each word in the slash text. The initial "orderchannelalert" is already removed by LibSlash.
  for param in text:gmatch ("%S+")
  do
    table.insert (params, param)
  end

  ----------------------------------------------------------------------------
  -- Duration
  ----------------------------------------------------------------------------

  if (params[1] == "duration")
  then
      
    local duration = tonumber (params[2])

    if (type (duration) ~= "number") or (duration < 0)
    then
      TextLogAddEntry ("Chat", 0, L"OrderChannelAlert: invalid value for alert duration: " .. towstring (params[2]))
      return
    end

    for _, cfg in pairs(OrderChannelAlert_Settings.abilities) do
      cfg.duration = duration
    end
    TextLogAddEntry ("Chat", 0, L"OrderChannelAlert: set duration for all abilities to " .. towstring (duration) .. L" seconds.")

  ----------------------------------------------------------------------------
  -- Help
  ----------------------------------------------------------------------------

  elseif (params[1] == "help")
  then

    TextLogAddEntry ("Chat", 0, L"---------------------------------------------")
    TextLogAddEntry ("Chat", 0, L"/orderchannelalert")
    TextLogAddEntry ("Chat", 0, L"- Opens the OrderChannelAlert configuration window.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/orderchannelalert duration #")
    TextLogAddEntry ("Chat", 0, L"- Sets the duration for ALL configured abilities (seconds).")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/orderchannelalert help")
    TextLogAddEntry ("Chat", 0, L"- Displays a list of all OrderChannelAlert chat commands.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/orderchannelalert debug on|off")
    TextLogAddEntry ("Chat", 0, L"- Enables/disables OrderChannelAlert debug messages.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/orderchannelalert layer #")
    TextLogAddEntry ("Chat", 0, L"- Sets which UI layer to show the alert window on. # can be: background, default, overlay, popup or secondary.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/orderchannelalert off")
    TextLogAddEntry ("Chat", 0, L"- Disables the alert.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/orderchannelalert on")
    TextLogAddEntry ("Chat", 0, L"- Enables the alert.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/orderchannelalert sound on|off")
    TextLogAddEntry ("Chat", 0, L"- Enables/disables sound for ALL configured abilities (main sound ID is 500).")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/orderchannelalert test")
    TextLogAddEntry ("Chat", 0, L"- Trigger the alert. For testing purposes.")
    TextLogAddEntry ("Chat", 0, L"---------------------------------------------")

  ----------------------------------------------------------------------------
  -- Layer
  ----------------------------------------------------------------------------

  elseif (params[1] == "layer")
  then

    local layer = params[2]

        if (layer == "background") then OrderChannelAlert_Settings.window_layer = Window.Layers.BACKGROUND
    elseif (layer == "default")    then OrderChannelAlert_Settings.window_layer = Window.Layers.DEFAULT
    elseif (layer == "overlay")    then OrderChannelAlert_Settings.window_layer = Window.Layers.OVERLAY
    elseif (layer == "popup")      then OrderChannelAlert_Settings.window_layer = Window.Layers.POPUP
    elseif (layer == "secondary")  then OrderChannelAlert_Settings.window_layer = Window.Layers.SECONDARY
    else
      TextLogAddEntry ("Chat", 0, L"OrderChannelAlert: invalid window layer. Valid options are: background, default, overlay, popup and secondary.")
    end

    WindowSetLayer (WINDOW_NAME, OrderChannelAlert_Settings.window_layer)
    TextLogAddEntry ("Chat", 0, L"OrderChannelAlert: alert window layer changed to: " .. towstring (layer))

  ----------------------------------------------------------------------------
  -- Off
  ----------------------------------------------------------------------------

  elseif (params[1] == "off")
  then

    OrderChannelAlert_Disable ()
    TextLogAddEntry ("Chat", 0, L"OrderChannelAlert: the alert is turned off.")

  ----------------------------------------------------------------------------
  -- On
  ----------------------------------------------------------------------------

  elseif (params[1] == "on")
  then

    OrderChannelAlert_Enable ()
    TextLogAddEntry ("Chat", 0, L"OrderChannelAlert: the alert is turned on.")

  ----------------------------------------------------------------------------
  -- Sound
  ----------------------------------------------------------------------------

  elseif (params[1] == "sound")
  then

    local arg = params[2]
    if not arg or arg == "" then
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: usage: /orderchannelalert sound on|off (main sound ID is 500)")
      return
    end

    local enable = nil
    if arg == "on" then
      enable = true
    elseif arg == "off" then
      enable = false
    else
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: invalid value. Usage: /orderchannelalert sound on|off")
      return
    end

    for _, cfg in pairs(OrderChannelAlert_Settings.abilities) do
      cfg.sound_enabled = enable
    end

    if enable then
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: enabled sound for all abilities (sound ID 500)")
    else
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: disabled sound for all abilities")
    end

  ----------------------------------------------------------------------------
  -- Debug
  ----------------------------------------------------------------------------

  elseif (params[1] == "debug")
  then

    local v = (params[2] or "")
    if v == "on" then
      OrderChannelAlert_Settings.debug = true
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: debug enabled.")
    elseif v == "off" then
      OrderChannelAlert_Settings.debug = false
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: debug disabled.")
    else
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: usage: /orderchannelalert debug on|off")
    end

  elseif (params[1] == "soundlist" or params[1] == "soundid")
  then

    local arg = params[2]
    if params[1] == "soundlist" then
      local names = {}
      if type(GameData) == "table" and type(GameData.Sound) == "table" then
        for name, id in pairs(GameData.Sound) do
          names[#names + 1] = tostring(name) .. "=" .. tostring(id)
        end
      end
      table.sort(names)
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: " .. towstring(#names) .. L" sounds. Use /orderchannelalert soundid <number> to audition and select one.")
      for i = 1, #names, 6 do
        TextLogAddEntry("Chat", 0, towstring(table.concat(names, "  ", i, math.min(i + 5, #names))))
      end
    elseif tonumber(arg) then
      OrderChannelAlert_Settings.sound_id = tonumber(arg)
      PlaySound(tonumber(arg))
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: alert sound set to " .. towstring(arg) .. L".")
    else
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: usage: /orderchannelalert soundlist | soundid <number> (current " .. towstring(OrderChannelAlert_Settings.sound_id or MAIN_SOUND_ID) .. L")")
    end

  ----------------------------------------------------------------------------
  -- Test
  ----------------------------------------------------------------------------

  elseif (params[1] == "test")
  then

    if not orderchannelalert_is_enabled then
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: turn the addon on before testing.")
      return
    end

    -- Optional: /orderchannelalert test <ability_id>
    local requested_id = tonumber(params[2])
    local test_ability_id = nil
    local testable_ability_ids = {}

    if requested_id then
      local requested_config = OrderChannelAlert_Settings.abilities[requested_id]
      if requested_config then
        test_ability_id = requested_id
      end
    else
      -- Cycle through every configured channel, regardless of tracking filters.
      for ability_id, config in pairs(OrderChannelAlert_Settings.abilities) do
        if type(ability_id) == "number" and config and type(config.texture) == "string" and config.texture ~= "" then
          table.insert(testable_ability_ids, ability_id)
        end
      end
      table.sort(testable_ability_ids)
      if #testable_ability_ids > 0 then
        test_ability_cursor = (test_ability_cursor % #testable_ability_ids) + 1
        test_ability_id = testable_ability_ids[test_ability_cursor]
      end
    end

    if test_ability_id then
      local cfg = OrderChannelAlert_Settings.abilities[test_ability_id]
      active_alerts = {}
      active_order = {}
      OrderChannelAlert_Trigger (test_ability_id, true)
      local ability_icon_id = OrderChannelAlert_AbilityIconId(test_ability_id)
      local dbg_tex, dbg_x, dbg_y
      if ability_icon_id and type(GetIconData) == "function" then
        dbg_tex, dbg_x, dbg_y = GetIconData(ability_icon_id)
      end
      TextLogAddEntry("Chat", 0, L"OrderChannelAlert: icon debug " .. towstring(tostring(dbg_tex)) .. L" " ..
        towstring(tostring(dbg_x)) .. L"x" .. towstring(tostring(dbg_y)) .. L" window " ..
        towstring(OrderChannelAlert_AbilityIconWindowName(1)) .. L" exists=" ..
        towstring(tostring(DoesWindowExist(OrderChannelAlert_AbilityIconWindowName(1)))))
      local tex = ""
      if cfg and cfg.texture then
        tex = tostring(cfg.texture)
      end
      local class_key = OrderChannelAlert_ClassInfoForTexture(tex)
      local class_label = class_key and OrderChannelAlert_ClassAbbreviations[class_key] or "Unknown"
      TextLogAddEntry("Chat", 0,
        L"OrderChannelAlert: test " .. towstring(test_ability_id) .. L" " ..
        towstring(cfg.name or "Unknown") .. L" (" .. towstring(class_label) .. L")" ..
        L" icon " .. towstring(ability_icon_id or "unavailable") ..
        (requested_id and L"" or L" [" .. towstring(test_ability_cursor) .. L"/" .. towstring(#testable_ability_ids) .. L"]"))
    else
      TextLogAddEntry ("Chat", 0, L"OrderChannelAlert: no channel abilities are configured.")
    end

  ----------------------------------------------------------------------------
  -- ???
  ----------------------------------------------------------------------------

  else

    TextLogAddEntry ("Chat", 0, L"OrderChannelAlert: missing or unknown command. Valid options are: duration, help, layer, off, on, sound and test.")

  end

end

function OrderChannelAlert_OnShutdown ()
end

function OrderChannelAlert_OnUpdate (time_delta)

  OrderChannelAlert_LayoutIconsIfNeeded()

  if layout_editor_active then
    return
  end

  now_seconds = now_seconds + (time_delta or 0)

  if sounds_remaining > 0 and now_seconds >= next_sound_at then
    PlaySound(OrderChannelAlert_Settings.sound_id or MAIN_SOUND_ID)
    sounds_remaining = sounds_remaining - 1
    next_sound_at = now_seconds + SOUND_REPEAT_INTERVAL
  end

  if #active_order <= 0 then
    if ui_dirty then
      OrderChannelAlert_RenderIcons()
      ui_dirty = false
    end
    return
  end

  local did_expire = false
  for i = #active_order, 1, -1 do
    local ability_id = active_order[i]
    local entry = active_alerts[ability_id]
    if (not entry) or (entry.expires_at <= now_seconds) then
      table.remove(active_order, i)
      active_alerts[ability_id] = nil
      did_expire = true
    end
  end

  if did_expire then
    ui_dirty = true
  end

  if ui_dirty then
    OrderChannelAlert_RenderIcons()
    ui_dirty = false
  end

end

function OrderChannelAlert_OnWorldObjCombatEvent (world_object_id, ability_value, ability_type, ability_id)

  -- Only check combat events that happen to the player.
  if (world_object_id ~= GameData.Player.worldObjNum)
  then
    return
  end

  -- Check if this ability is in our config and enabled
  local ability_config = OrderChannelAlert_Settings.abilities[ability_id]
  if ability_config and ability_config.enabled and OrderChannelAlert_IsClassTracked(ability_config.texture) then
    OrderChannelAlert_Trigger (ability_id)
  end

end
